/** Automatically generated file. DO NOT MODIFY */
package singh.saurabh.brokenbatcity;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}