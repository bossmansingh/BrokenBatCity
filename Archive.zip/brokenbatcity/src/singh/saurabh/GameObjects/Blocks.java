package singh.saurabh.GameObjects;

import com.badlogic.gdx.math.Rectangle;

public class Blocks extends Scrollable {
	
	private Rectangle block;
	private float groundY;
	private boolean isScored = false;
	
	public Blocks(float x, float y, int width, int height, float scrollSpeed, float groundY) {
		super(x, y, width, height, scrollSpeed);
		
		// Initialize a Random object for Random number generation
        
        block = new Rectangle();
        this.groundY = groundY;
	}

	@Override
    public void update(float delta) {
        // Call the update method in the superclass (Scrollable)
        super.update(delta);

        // The set() method allows you to set the top left corner's x, y
        // coordinates,
        // along with the width and height of the rectangle
        
        block.set(position.x, position.y + groundY, 100, 60);

    }
	
    public void onRestart(float x, float scrollSpeed) {
        velocity.x = scrollSpeed;
        reset(x);
    }
    
    @Override
    public void reset(float newX) {
        // Call the reset method in the superclass (Scrollable)
        super.reset(newX);
        // Change the height to a random number
        height = 60;
        isScored = false;
    }
    
    public Rectangle getBlock() {
    	return block;
    }
    
    public boolean isScored() {
        return isScored;
    }

    public void setScored(boolean b) {
        isScored = b;
    }
}
